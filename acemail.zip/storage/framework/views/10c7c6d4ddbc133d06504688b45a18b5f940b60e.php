<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="content">
        <div class="title">
            <h2>Welcome Funke,</h2>
            <img src="./img/logo.png" width="70px" alt="">
        </div>

        <div class="holder">
            <i>Here are your details:</i>
            <div class="">
                <p class="boldit"><span>Surname:</span> Olasupo</p>
                <p class="boldit"><span>First Name:</span> Funke</p>
                <p class="boldit"><span>Middle Name:</span> Roxie</p>
                <p class="boldit"><span>Matric Number:</span> 170234098</p>
                <p class="boldit"><span>Email:</span> roxie@gmail.com</p>
                <p class="boldit"><span>Default Password:</span> student@1234</p>
            </div>
        </div>
    </div>



    <style>
        body {
            background-color: #131416;
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, Helvetica, sans-serif;
        }

        .content {
            background-color: #fff;
            /* padding: 25px; */
            border-radius: 5px;
            width: 30%;
            border-bottom: 5px solid rgba(0, 128, 0, 0.753);
        }

        .title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgba(0, 128, 0, 0.753);
            padding: 15px;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            color: #fff;
        }

        .holder {
            margin: 25px 15px;
            width: 100%;
        }


        .matric {
            width: 90%;
            padding: 13px 10px;
        }

        .matric:focus {
            outline: none;
            border: 2px solid rgba(0, 128, 0, 0.753);
            border-radius: 2px;
        }

        .boldit{
            font-weight: bold;
        }

        span{
            text-transform: uppercase;
            font-weight: lighter;
        }

        @media  only screen and (max-width: 600px) {
            .content {
                width: 98%;
            }
        }
    </style>

</body>

</html><?php /**PATH C:\xampp\htdocs\adeyemi\resources\views/hi.blade.php ENDPATH**/ ?>